<?php
/**
 * PageAsset
 * For asset management
 *
 * Configuration (via MODX System Settings)
 */
namespace Assman;

class PageAsset extends BaseModel {

    public $xclass = 'PageAsset';

}
/*EOF*/