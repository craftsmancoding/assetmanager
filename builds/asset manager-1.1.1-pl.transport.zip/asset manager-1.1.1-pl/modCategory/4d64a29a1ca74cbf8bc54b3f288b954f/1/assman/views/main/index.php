
<div class="assman_canvas_inner">
	<h2 class="assman_cmp_heading" id="assman_pagetitle"><?php print $this->modx->lexicon('assman.index.pagetitle') ?></h2>
</div>

<div class="x-panel-body panel-desc x-panel-body-noheader x-panel-body-noborder">
<p><?php print $this->modx->lexicon('assman.index.subtitle') ?></p>
</div>