<?php
return array(
    array(
        'content_type_id' => 9,
        'title' => 'Tie Dye',
        'url' => 'http://www.sunshinejoy.com/images/WholesaleTieDye/tie-dye_t-shirts_02.jpg',    
        'is_image' => 1,
    )
);
/*EOF*/