<?php

$xpdo_meta_map = array (
  'xPDOObject' => 
  array (
    0 => 'Asset',
  ),
  'xPDOSimpleObject' => 
  array (
    0 => 'PageAsset',
  ),
);