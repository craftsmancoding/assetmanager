
<div class="assman_canvas_inner">
	<h2 class="assman_cmp_heading" id="assman_pagetitle">Welcome to the MODX Asset Manager / Media Library.</h2>
</div>

<div class="x-panel-body panel-desc x-panel-body-noheader x-panel-body-noborder">
<p>Stay tuned... more tools and stuff will be here in future versions.</p>
</div>