
</div><!-- /assman_canvas -->

<div id="assman_footer">

	<ul>
		<li class="assman_nav_item"><a class="assman_donation_link" href="#">Make a Donation</a></li>
		<li class="assman_nav_item"><a class="assman_bug_link" href="https://github.com/craftsmancoding/assetmanager/issues/new">Report a Bug</a></li>
		<li class="assman_nav_item"><a class="assman_wiki_link" href="https://github.com/craftsmancoding/assetmanager/wiki">Wiki</a></li>
		<li class="assman_nav_item"><a class="assman_support_link" href="http://craftsmancoding.com/contact">Get Paid Support</a></li>
		
	</ul>
   
    <div id="assman_copyright">&copy; 2014 and beyond by <a href="http://craftsmancoding.com/">Craftsman Coding</a></div>
</div>