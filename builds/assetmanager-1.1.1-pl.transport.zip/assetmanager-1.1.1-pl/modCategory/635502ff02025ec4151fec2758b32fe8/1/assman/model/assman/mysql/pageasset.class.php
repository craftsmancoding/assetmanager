<?php
require_once (dirname(dirname(__FILE__)) . '/pageasset.class.php');
class PageAsset_mysql extends PageAsset {}