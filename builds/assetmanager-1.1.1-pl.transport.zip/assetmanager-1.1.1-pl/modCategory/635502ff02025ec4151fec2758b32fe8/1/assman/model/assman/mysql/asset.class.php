<?php
require_once (dirname(dirname(__FILE__)) . '/asset.class.php');
class Asset_mysql extends Asset {}